package com.mst.model;

public class Product {

	private String description ;

	public Product(String string) {
		// TODO Auto-generated constructor stub
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
}
