package di.byName;

import java.util.List;

public interface ProductService {

	 List<Product> listProducts();
	 
	 
}
